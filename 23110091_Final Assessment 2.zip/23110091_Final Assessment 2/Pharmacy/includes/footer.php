<div class="bg-danger p-3 text-center ">
  <p class="text-light">All rights reserved ©- Design by Ernest Chen-2025</p>
</div>