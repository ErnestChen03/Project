import java.util.ArrayList;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		ArrayList<String> names = new ArrayList<String>();
		String name;
		
		System.out.print("Enter name (-1 to end loop): ");
		name = input.nextLine();
		
		while (!name.equals("-1")) {
			//check duplication, if not duplicate, add to the array
			if (names.contains(name)) {
				System.out.println("Duplicate!");
			}
			else {
				names.add(name);
			}
			System.out.print("Enter name (-1 to end loop): ");
			name = input.nextLine();
			
			
		}
		
		//sort the array
		java.util.Collections.sort(names);
		
		System.out.println("The name you entered are: ");
		//print the array using a loop
		for (String n: names) {
			System.out.print(n +", ");
		}
		
		//OR
		/*
		for (int index=0 ; index<names.size(); index++) {
			System.out.print(names.get(index) + ",");
		}
		*/
		
		//additional:
		//ask user to enter name to delete
		System.out.println("\nEnter name to be deleted: ");
		name = input.nextLine();
		names.remove(name);
		
		//print the array using a loop 
		for (String n: names) {
			System.out.print(n +", ");
		}
		
		//additional
		//ask the user to enter name to search
		System.out.println("\nEnter name you want to search: ");
		name = input.nextLine();
		System.out.println("The name is at index: " + java.util.Collections.binarySearch(names, name));
		
	}
	

}
