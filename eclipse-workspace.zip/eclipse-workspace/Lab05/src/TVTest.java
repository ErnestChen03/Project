import java.util.Scanner;


public class TVTest {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		TV tv1 = new TV("S101", "Elba", 'R', 1400);
		
		System.out.println("Enter a price:");
		tv1.setPrice(input.nextInt());
		
		System.out.println("Tax is: " + tv1.calculateTax(10));

	}

}
