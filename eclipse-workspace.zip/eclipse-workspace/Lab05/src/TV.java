public class TV 
{
	private String stockNumber;
	private String make;
	private char screenType;
	private double price;
	public TV(String s, String m,char t, double p)
	{
		stockNumber = s;
		make = m;
		screenType = t;
		price = p;
	}
	public void setPrice(double p)
	{
		price = p;
	}
	public String getStockNumber()
	{
		return stockNumber;
	}
	public String getMake()
	{
		return make;
	}
	public char getScreenType()
	{
		return screenType;
	}
	public double getPrice()
	{
		return price;
	}
	public double calculateTax(double rateIn)
	{
		return price * rateIn/100;
	} 

}
