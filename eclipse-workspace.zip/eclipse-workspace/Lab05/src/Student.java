
public class Student {
	//attributes 
	private String name;
	private int semester;
	private String course;
	//constructors
	public Student() {
		name = "";
		semester = 1;
		course = "";
	}
	public Student(String n, int s, String c) {
		name = n;
		semester = s;
		course = c;
	}
	//setters/getters
	public String getName() {
		return name;
	}
	public void setName(String n) {
		name = n;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int s) {
		semester = s;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String c) {
		course = c;
	}
	
	//other methods
	public boolean checkEligibility() {
		if (semester >=4 && semester <=6) {
			return true;
		}
		else
			return false;
	}
	//toString method
	@Override
	public String toString() {
		return String.format(
				"Student with name %s studies course %s in semester %d", name, course, semester);

	}

}
