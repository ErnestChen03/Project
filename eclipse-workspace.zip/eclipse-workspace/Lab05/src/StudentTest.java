import java.util.ArrayList;

public class StudentTest {

	public static void main(String[] args) {
		ArrayList<Student> students = new ArrayList<Student>();
		Student student1 = new Student("Alex", 5, "BCS");
		Student student2 = new Student();
		student2.setName("Mindy");
		student2.setSemester(2);
		student2.setCourse("BIT");
		System.out.println(student1);
		System.out.println(student2);
		student1.setName("Johnson");
		
		
		students.add(student1);
		students.add(student2);
		for(Student s: students) {
			System.out.print(s);
			System.out.print(s.checkEligibility()? " is eligible": " is not eligible");
			System.out.print(" to get credit exemption\n");
		}
		
		//Alternative way without using Array
		System.out.print(student1);
		System.out.print(student1.checkEligibility()? " is eligibile": " is not eligibile");
		System.out.print(" to get credit exemption\n");
		
		System.out.print(student2);
		System.out.print(student2.checkEligibility()? " is eligibile": " is not eligibile");
		System.out.print(" to get credit exemption\n");
		
		//System.out.print(student2.checkEligibility()? "is eligible": " is not eligible");
		//equivalent to:
		if(student2.checkEligibility()) {
			System.out.print(" is eligible");
		}
		else {
			System.out.print(" is not eligible");
		}

	}

}
