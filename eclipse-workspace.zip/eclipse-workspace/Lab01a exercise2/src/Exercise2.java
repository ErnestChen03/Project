import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		int number;
		int digit1, digit2, digit3, digit4, digit5;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a five digit number: ");
		number = input.nextInt();
		
		digit1 = number / 10000; //43978 / 10000 = 4
		digit2 = (number % 10000) / 1000; //43978 % 10000 = 3978 / 1000 = 3
		digit3 = (number % 1000) / 100;
		digit4 = (number % 100) / 10;
		digit5 = number % 10;
		
		/*
		System.out.println("first digit is :" + digit1);
		System.out.println("second digit is :" + digit2);
		System.out.println("third digit is :" + digit3);
   		System.out.println("forth digit is :" + digit4);
   		System.out.println("fifth digit is :" + digit5);
		*/
		
		System.out.println("Digit in " + number + " are " + digit1 + " " + digit2 + " " + digit3 + " " + digit4 + " " + digit5);
		System.out.printf("Digit in %d are %d %d %d %d %d",number,digit1,digit2,digit3,digit4,digit5);

	}

}
