import com.prg1203.package1.*;
import com.prg1203.package2.*;
public class TestAnother {

	public static void main(String[] args) {
		//create an object which is not in this project
		ClassA obj1 = new ClassA();
		ClassB obj2 = new ClassB();

	}

}
