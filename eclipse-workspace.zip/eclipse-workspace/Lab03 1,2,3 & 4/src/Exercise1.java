import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		//calculate the summation of 1 to n number by calling the recursive function
		int result;
		int num;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a number: ");
		num = input.nextInt();
		result = sum(num); //let say if num is 5
		System.out.println("Result is " + result); //the result is 15 (1 + 2 + 3 + 4 + 5)
		
	}
	
	//recursive function
	public static int sum(int n)
	{
		//base case
		if (n == 1) {
			return 1;
		}
		else {
		//recursive step
			return (n + sum(n-1));
		}
			
	}

}
