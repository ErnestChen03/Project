import java.io.File;
import java.io.FileNotFoundException;
import java.lang.SecurityException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Exercise4 {
	public static void main(String[] args) 
	{
		Scanner input;
		try {
			input = new Scanner(new File("students.txt"));
			while (input.hasNext())
			{
				System.out.printf("%-15s%-10d\n", input.next(), input.nextInt());
			}
			if (input !=null)
			{
				input.close();
			}
		} catch (FileNotFoundException fe)
		{
			System.out.println("Error opening file.");
		}
		catch (NoSuchElementException ex)
		{
			System.out.println("File improperly formed.");
		}
		

	}

}
