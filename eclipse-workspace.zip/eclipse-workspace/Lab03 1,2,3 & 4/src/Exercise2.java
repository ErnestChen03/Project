import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		int[] nums = new int[5];
		int result;
		Scanner input = new Scanner(System.in);
		
		try {
			//ask user to enter number to array
			for(int i=0;i<5;i++) {
				System.out.println("Enter numbers: ");
				nums[i] = input.nextInt();
			}
	
			//write a statement to divide a number with zero
			result = nums[0] / nums[1];
			
			//try to access the element 6 in the array
			nums[5] = 10;
		}
		catch(InputMismatchException e) {
			System.out.println("Wrong input format");
		}
		catch(ArithmeticException e) {
			System.out.println("Cannot divided by zero");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Index out of bound");
		}
		catch(Exception e) {
			
			System.out.println("Error:" + e);
		}
		//run the code for each of the scenario and capture the exception
		//then handle it with the try...catch block
		
		//InputMismatchException
		//ArithmeticException
		//ArrayIndexOutOfBoundsException
		
	}

}
