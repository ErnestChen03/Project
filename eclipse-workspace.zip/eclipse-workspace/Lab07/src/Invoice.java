
public class Invoice {

	private String partNumber;
	private String partDescription;
	private int quantity;
	private double pricePerItem;
	
	public Invoice()
	{
		partNumber = "";
		partDescription = "";
		quantity = 0;
		pricePerItem = 0;
	}
	
	public Invoice(String pn, String pd, int qty, double price) {
		partNumber = pn;
		setPartNumber(pn);
		setPartDescription(pd);
		setQuantity(qty);
		setPricePerItem(price);
	}
	
	public String getPartNumber() {
		return partNumber;
	}
	
	public void setPartNumber(String pn) {
		partNumber = pn;
	}
	
	public String getPartDescription() {
		return partDescription;
	}
	
	public void setPartDescription(String pd) {
		partDescription = pd;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int qty) {
		if(qty < 0)
		{
			quantity = 0;
		}
		else {
			quantity = qty;
		}
	}
	
	public double getPricePerItem() {
		return pricePerItem;
	}
	
	public void setPricePerItem(double price) {
		if (price < 0)
		{
			pricePerItem = 0;
		}
		else
		{
			pricePerItem = price;
		}
	}
	public double getInvoiceAmount()
	{
		return getQuantity() * getPricePerItem();
	}
	
	public String toString()
	{
		return String.format("Part Number: %s\n Part Description: %s\n Quantity: %d\n Price: %.2f\n Invoice amount: %.2f\n",
				getPartNumber(), getPartDescription(), getQuantity(), getPricePerItem(), getInvoiceAmount());
	}
}
