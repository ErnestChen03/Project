import java.util.Scanner;

public class Question_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int num;
		int digit1, digit2, digit3, digit4, digit5;
		
		System.out.println("Enter five digit integer: ");
		num=input.nextInt(); //let say we enter 12345
		
		digit1 = num/ 10000;
		digit2 = (num%10000)/1000;
		digit3 = (num%1000)/100;
		digit4 = (num%100)/10;
		digit5 = (num%10)/1;
		
		System.out.printf("First digit is %d\n", digit1);
		System.out.printf("Second digit is %d\n", digit2);
		System.out.printf("Third digit is %d\n", digit3);
		System.out.printf("Fourth digit is %d\n", digit4);
		System.out.printf("Fifth digit is %d\n", digit5);
		
		System.out.printf(digit1 +" "+ digit2 + " " + digit3 + " " +digit4 + " " +digit5);
		
		
	}

}
