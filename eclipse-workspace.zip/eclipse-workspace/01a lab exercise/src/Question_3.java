import java.util.Scanner;
public class Question_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int num;
		System.out.println("Enter an integer: ");
		num = input.nextInt();
		
		if(num%2==0)
			System.out.printf("%d is an even number ", num);
		else
			System.out.printf("%d is an odd number ", num);
	}

}
