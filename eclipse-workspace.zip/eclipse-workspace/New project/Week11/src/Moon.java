
public class Moon extends SpaceObject{
	
	public Moon() {
		super(3);
	}
	
	@Override 
	public void draw() {
		//moon
		System.out.println("         ___---___                    ");
		System.out.println("      .--         --.      ");
		System.out.println("    ./   ()      .-. \\.");
		System.out.println("   /   o    .   (   )  \\");
		System.out.println("  / .            '-'    \\         ");
		System.out.println(" | ()    .  O         .  |      ");
		System.out.println("|                         |      ");
		System.out.println("|    o           ()       |");
		System.out.println("|       .--.          O   |            ");
		System.out.println(" | .   |    |            |");
		System.out.println("  \\    `.__.'    o   .  /    ");
		System.out.println("   \\                   /                   ");
		System.out.println("    `\\  o    ()      /'          ");
		System.out.println("      `--___   ___--'");
		System.out.println("            ---");
	}
}
