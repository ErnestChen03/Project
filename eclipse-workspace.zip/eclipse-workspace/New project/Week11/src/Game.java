//controller

import java.util.ArrayList;

public class Game {
	private ArrayList<SpaceObject> slist = new ArrayList<SpaceObject>();
	
	public Game() {
		Rocket r = new Rocket();
		SpaceObject s = new SpaceObject();
		Moon m = new Moon();
		
		for(int i=0; i<3; i++) {
			slist.add(new Astronaut());
		}
		
		slist.add(r);
		slist.add(s);
		slist.add(m);
		
		for(int i=0; i<5; i++) {	
			slist.add(new Rocket());
		}
		
		Astronaut a = new Astronaut();
		slist.add(a);
		
	}
	
	public void start() {
		for(SpaceObject s: slist) {
			System.out.println(s.getClass().getName());
			System.out.println("ID:" + s.getID() + ", power:" + s.getPower());
			s.draw();
			//check make sure it is astronaut
			if (s instanceof Astronaut) {				
				((Astronaut) s).wave();
			}
		}
	}
	
	
	
}
