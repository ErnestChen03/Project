
public class SpaceObject {
	private int ID;
	private int power;
	
	public SpaceObject() {
		ID = 0;
	}
	
	public SpaceObject(int ID) {
		this.ID = ID;
	}
	
	public void draw() {
		System.out.println("I don't know what to draw....");
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}
	
	
}
