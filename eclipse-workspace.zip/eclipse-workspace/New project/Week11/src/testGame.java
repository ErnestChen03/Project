//driver class -> as simple as possible
public class testGame {

	public static void main(String[] args) {
		Game g1 = new Game();
		g1.start();		
		
		
	}

}
