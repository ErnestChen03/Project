package lab11q2;

public class Bird {

public class Bird {
	private String name;
	private int leg;
	private int meter = 0;
	
	public Bird(String name, int leg) {
		this.name = name;
		this.leg = leg;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLeg() {
		return leg;
	}
	public void setLeg(int leg) {
		this.leg = leg;
	}
	public int getMeter() {
		return meter;
	}
	public void setMeter(int meter) {
		this.meter = meter;
	}
	public void Eat() {
		System.out.println("Eating\n");
	}
	public void Sing() {
		System.out.println("Singing\n");
	}
	public void Fly() {
		System.out.printf("Flying %d meter\n", meter);
	}
	
	@Override
	public String toString() {
		return String.format("Bird [name=%s, leg=%s, meter=%s]", name, leg, meter);
	}

}

}
