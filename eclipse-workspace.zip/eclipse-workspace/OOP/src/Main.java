
public class Main {

	public static void main(String[] args) {
		
		Car myCar1 = new Car();
		Car myCar2 = new Car();
		
		System.out.println(myCar1.make);
		System.out.println(myCar1.model);
		System.out.println();
		System.out.println(myCar1.make);
		System.out.println(myCar2.model);
		

		
		//object = an instance of a class that may contain attributes and methods
		//examples: (phone, desk, computer, coffee cup)
	}
}
