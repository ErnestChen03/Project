
public class TV {
	//attributes
	private String stockNumber;
	private String make;
	private char ScreenType;
	private double price;
	
//constructor
public TV(String s, String m, char t, double p)
{
	stockNumber = s;
	make = m;
	ScreenType = t;
	price = p;
}
//setters getters
public void setPrice(double p) {
	price = p;
}

public String getStockNumber() {
	return stockNumber;
}

public String getMake() {
	return make;
}
public char getScreen() {
	return ScreenType;
}
public double getPrice() {
	return price;
}
public double CalculateTax(double rateIn) {
	return price "rateIn/100;
}
}
