package com.prg1203.package2;

public class ClassB {

}
