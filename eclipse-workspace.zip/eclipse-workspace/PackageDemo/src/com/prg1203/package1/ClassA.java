package com.prg1203.package1;

public class ClassA {

}
