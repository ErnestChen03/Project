package com.prg1203.package1;
import com.prg1203.package2.*;


public class TestPackage {

	public static void main(String[] args) {
		//create an object for ClassA which is in the same package as this  driver class 
		ClassA obj1 = new ClassA();
		
		//create an object for ClassB which is in the different package of this driver class
		ClassB obj2 = new ClassB();
	
	}

}
