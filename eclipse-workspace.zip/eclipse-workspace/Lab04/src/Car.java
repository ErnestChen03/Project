
public class Car {
	//attributes
	private String brand;
	private String colour;
	private int engine_size;
	private int speed;
	
	//constructors
	public Car() { //set the default value for the attributes
		brand = "no brand";
		colour = "white";
		engine_size = 2;
		speed = 0;
	}
	
	public Car(String b, String c, int e, int s) {
		brand = b;
		colour = c;
		engine_size = e;
		speed = s;
	}
	
	//setters/getters
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String b) {
		brand = b;
	}
	
	public String getColour() {
		return colour;
	}
	
	public void setColour(String c) {
		colour = c;
	}
	
	public int getEngine_size() {
		return engine_size;
	}
	
	public void setEngine_size(int e) {
		engine_size = e;
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void setSpeed(int s) {
		speed = s;
	}
	//other Methods
	public void accelerate() {
		speed = speed + 1;
	}
	
	public void decelerate() {
		speed = speed - 1;
	}
	
	public void stop() {
		speed = 0;
	}
	//toString
	public String toString() {
		return String.format("The car with brand %s, color %s, engine size %d is running at speed %d",  brand, colour, engine_size, speed);
	}
}
