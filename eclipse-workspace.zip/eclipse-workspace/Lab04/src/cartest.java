import java.util.ArrayList;

public class cartest {
	
	public static void main(String[] args) {
		ArrayList<Car> carlist = new ArrayList<Car>();
		
		Car car1 = new Car(); //calling default/empty constructor
		Car car2 = new Car("Toyota", "red", 3, 1); //calling the complete
		Car car3 = new Car("Honda", "yellow", 1, 0);
		
		carlist.add(car1);
		carlist.add(car2);
		carlist.add(car3);
		
		System.out.println("Car 1:" + car1);
		System.out.println("Car 2:" + car2);
		System.out.println("Car 3:" + car3);
		
		car1.setBrand("BMW");
		System.out.println("Car 1:" + car1);
		
		//System.out.println("The colours for the cars are:" + car1.getColour() + "," + car2.getColour() + "," + car3.getColour());
		System.out.printf("The colours for the cars are %s, %s, %s\n", car1.getColour(), car2.getColour(), car3.getColour());
	
		car1.accelerate();
		car1.accelerate();
		car2.stop();
		
		System.out.println("Car 1:" + car1);
		System.out.println("Car 2:" + car2);
		System.out.println("Car 3:" + car3);
		
		for(Car c: carlist) {
			c.accelerate();
			c.accelerate();
			c.accelerate();
			System.out.println(c);
			
		}
	
		
	
	}

}
