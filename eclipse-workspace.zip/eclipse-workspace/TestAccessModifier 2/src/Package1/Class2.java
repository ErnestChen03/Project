package Package1;

public class Class2 {

}
