import java.util.Scanner;

public class AccountTest {
	public static void main(String[] args) {
		double num;
		Scanner input = new Scanner(System.in);
		
		//create account1 & account2
		System.out.print("account1 balance:$");
		num = input.nextDouble();
		Account account1 = new Account(num);
		System.out.print("account2 balance:$");
		num = input.nextDouble();
		Account account2 = new Account(num);
		//display balance
		System.out.printf("account1 balance: %.2f\n", account1.getBalance());
		System.out.printf("account2 balance: %.2f\n", account2.getBalance());
		
		//ask for deposit amount
		System.out.print("Enter amount to be deposited for account1:$");
		num = input.nextDouble();
		account1.credit(num);
		System.out.print("Enter amount to be deposited for account2:$");
		num = input.nextDouble();
		account2.credit(num);
		//display balance
		System.out.printf("account1 balance: %.2f\n", account1.getBalance());
		System.out.printf("account2 balance: %.2f\n", account2.getBalance());
		
		//ask for withdraw amount
		System.out.print("Enter amount to be withdrawn for account1:$");
		num = input.nextDouble();
		account1.debit(num);
		System.out.print("Enter amount to be withdrawn for account2:$");
		num = input.nextDouble();
		account2.debit(num);
		
		//display balance
		System.out.printf("account1 balance: %.2f\n", account1.getBalance());
		System.out.printf("account2 balance: %.2f\n", account2.getBalance());
		
		
		//print the total amount that the bank has for all the accounts
		//double total = account1.getBalance() + account2.getBalance();
		System.out.println("Total that bank has is:" + Account.getTotal());
		
	
	
	}

}
