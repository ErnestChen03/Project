/**
 * Product class is the class for a xxxx yyyy
 *
 * line 2
 * 
 * line 3
 * 
 * 
 * @author Ernest Chen
 * 
 */

public class Product {
	//attributes/fields/instance variables
	private String title;
	private double price;
	/** qty is the quantity for a particular product */
	private int qty;
	
	
	public Product() {
		this("noname", 10, 1);
		
	}

	/** this is the complete constructor to xxxx
	 * 
	 * @param title this is the product tile
	 * @param price this is the price of a single product
	 * @param qty this is the quantity of the product stock
	 */
	public Product(String title, double price, int qty) {
		this.title = title;
		this.price = price;
		this.qty = qty;
	}

	/** this is the getter for title
	 * 
	 * @return this method will return a product title
	 */
	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQty() {
		return qty;
	}


	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return String.format("Product [title=%s, price=%s, qty=%s]", title, price, qty);
	}
	
	
}
