public class Battle {
    private Pokemon playerPokemon;
    private Pokemon wildPokemon;

    public Battle(Pokemon playerPokemon, Pokemon wildPokemon) {
        this.playerPokemon = playerPokemon;
        this.wildPokemon = wildPokemon;
    }

    public void initiateBattle() {
        while (playerPokemon.getHP() > 0 && wildPokemon.getHP() > 0) {
            performTurn(playerPokemon, wildPokemon);
            if (wildPokemon.getHP() > 0) {
                performTurn(wildPokemon, playerPokemon);
            }
        }
    }

    private void performTurn(Pokemon attacker, Pokemon defender) {
        int damage = calculateDamage(attacker, defender);
        defender.takeDamage(damage);
    }

    private int calculateDamage(Pokemon attacker, Pokemon defender) {
        // Logic to calculate damage
        return attacker.getAttackPoints();
    }
}
