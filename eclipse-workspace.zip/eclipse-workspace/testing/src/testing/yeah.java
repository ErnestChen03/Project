package testing;

public class yeah {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if(studentGrade>=90)
			System.out.print("A");
		else if(studentGrade>=80)
			System.out.print("B");
		else if(studentGrade>=70)
			System.out.print("C");
		else if(studentGrade>=60)
			System.out.print("D");
		else
			System.out.print("F");

	}

}
