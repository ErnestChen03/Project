import java.util.Scanner;

public class Exercise1 {
	public static void main(String[] args) {
		//define an original array with 5 elements type int
		int[] numbers;
		numbers = new int[5];
		int count = 0;
		int number;
		Scanner input = new Scanner(System.in);
		
		while(count < numbers.length) {
			System.out.print("\nEnter a number: ");
			number = input.nextInt();
			if ((number >= 10) && (number <= 100)) {
				//duplication checking
				//loop through the array and compare the number one by one
				boolean containsNumber = false;
				for (int index = 0; index < numbers.length; index++) {
					if (number == numbers[index]) {
						containsNumber = true;
						break;
					}
				}
				if (!containsNumber) {
					numbers[count] = number;
					count++;
				}
				else {
					System.out.printf("%d has already been entered\n",number);
				}
			}
			else {
				System.out.println("number must be between 10 and 100");
			}
			
			//print out the number in array
			for (int index = 0; index < count; index++)
			{
				System.out.print(numbers[index] + " ");
			}
		}
		
		//create a loop to read in 5 numbers from user and store in your array progressively
		

	}

}
