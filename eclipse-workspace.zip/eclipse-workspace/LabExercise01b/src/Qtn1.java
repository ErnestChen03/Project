import java.util.Scanner;
public class Qtn1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		int qty, prodnum = 1;

		double product1 = 0;
		double product2 = 0;
		double product3 = 0;
		double total = 0;
		
		while(prodnum!=0) {
		System.out.println("Enter product number (1-3) (0 to stop): ");
		prodnum = input.nextInt();
		
		if(prodnum!=0) {
		
			System.out.println("Enter quantity sold: ");
			qty = input.nextInt();
		
			switch(prodnum) {	
				case 1:
					total = qty * 2.98;
					product1 = product1 + total; //accumulation for total product1
					break;
				case 2:
					total = qty * 4.50;
					product2 = product2 + total;
					break;
				case 3:
					total = qty * 9.98;
					product3 = product3 + total;
					break;
		
					
				default:
					System.out.println("Invalid product code");
					
					
				}//end switch
		
	  }//end if
	}//end while
		System.out.printf("Product 1:RM	$%.2f\n",product1);
		System.out.printf("Product 2:RM	$%.2f\n",product2);
		System.out.printf("Product 3:RM	$%.2f\n",product3);
	 
	}
}
