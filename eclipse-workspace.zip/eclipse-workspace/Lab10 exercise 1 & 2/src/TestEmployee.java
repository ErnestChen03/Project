
public class TestEmployee {
	
	public static void main(String[] args) {
		//composition
		
		Date bd = new Date(17, 8, 1990);
		Date hd = new Date(25, 6, 2014);
		
		Employee emp = new Employee("George", "Tan",bd, hd);
		
		System.out.println(emp);
		
		emp.setLastName("Chan");
		
		System.out.println(emp);
		
		//let's change the hire date
		
		System.out.println(emp);
	}

}
