import java.util.ArrayList;
import java.util.Date;

public class Event {

	private String evtname;
	private Organizer organizer;
	private String category;
	private Date date;
	private String time;
	private ArrayList<Member> memberList = new ArrayList<>();
	private String location;

	public Event() {

	}

	public Event(String evtname, Organizer organizer, String category, Date date, String time,
			ArrayList<Member> memberList, String location) {
		super();
		this.evtname = evtname;
		this.organizer = organizer;
		this.category = category;
		this.date = date;
		this.time = time;
		this.memberList = memberList;
		this.location = location;
	}

	public String getEvtname() {
		return evtname;
	}

	public void setEvtname(String evtname) {
		this.evtname = evtname;
	}

	public Organizer getOrganizer() {
		return organizer;
	}

	public void setOrganizer(Organizer organizer) {
		this.organizer = organizer;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public ArrayList<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(ArrayList<Member> memberList) {
		this.memberList = memberList;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return String.format(
				"Event [evtname=%s, organizer=%s, category=%s, date=%s, time=%s, memberList=%s, location=%s]", evtname,
				organizer, category, date, time, memberList, location);
	}

}
