
public class Organizer extends User{
	
	private String RegNumber;
	
	public Organizer() 
	{
		
	}

	public Organizer(String name, String contact, String email, String password, String regNumber) {
		super(name, contact, email, password);
		RegNumber = regNumber;
	}

	public String getRegNumber() {
		return RegNumber;
	}

	public void setRegNumber(String regNumber) {
		RegNumber = regNumber;
	}

	@Override
	public String toString() {
		return String.format("Organizer [RegNumber=%s]", RegNumber);
	}
	
	
	
	
	
	
	
	
}
