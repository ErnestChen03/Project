import java.util.ArrayList;
import java.util.Date;

public class programTest {
	
	public static void main(String[] args) {
		
	
	
	Organizer o1 = new Organizer("george", "abc@gmail.com", "01333333", "1234", "ABC");
	Member m1 = new Member();
	Member m2 = new Member();
	Date d1 = new Date();
	
	ArrayList<Member> mlist = new ArrayList<Member>();
	mlist.add(m1);
	mlist.add(m2);
	
	Event e1 = new Event("HarryPoterEvent", o1, "Movie", d1, "12:30", mlist, "Sunway University");
			
	}

}
