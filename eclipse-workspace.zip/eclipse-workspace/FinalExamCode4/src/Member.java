
public class Member extends User{
	
	private int age;
	private char gender;
	
	public Member() {
		
	}
	
	public Member(String name, String contact, String email, String password, int age, char gender) {
		super(name, contact, email, password);
		this.age = age;
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return String.format("Member [age=%s, gender=%s]", age, gender);
	}
	
	
	
	
	
	

}
