import java.util.ArrayList;

public class ReviewPage {
	
	private ArrayList<Review> reviewlist = new ArrayList<Review>();
	
	private ReviewPage() {
		
	
	}

	public ReviewPage(ArrayList<Review> reviewlist) {
		this.reviewlist = reviewlist;
	}

	public ArrayList<Review> getReviewlist() {
		return reviewlist;
	}

	public void setReviewlist(ArrayList<Review> reviewlist) {
		this.reviewlist = reviewlist;
	}

	@Override
	public String toString() {
		return String.format("ReviewPage [reviewlist=%s]", reviewlist);
	}
	
	
	
	
}
