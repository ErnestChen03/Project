
public class Date {
	private int day; //day of the month
	private int month; //month in the year
	private int year; //year
	private static final String[] monthNames = {"January", "February", 
			"March", "April", "May", "June", "July", "August",
			"September", "October", "November", "December"};
	private static final int[] monthDays = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	
	//no-argument constructor
	public Date()
	{
		this(1,1,2012);
		/*
		 setYear(2012);
		 setMonth(1);
		 setDay(1);
		 */
	}
	// constructor for format DD/MM/YYYY
	public Date(int dd, int mm, int yyyy)
	{
		setYear(yyyy);
		setMonth(mm);
		setDay(dd);
	}	//end constructor for format DD/MM/YYYY
	
	//constructor for format MonthName dd, yyyy
	public Date(String mm, int dd, int yyyy)
	{
		setYear(yyyy);
		convertFromMonthName(mm);
		setDay(dd);
	} //end constructor for format MonthName dd, yyyy
	
	//constructor for format DDD YYYY
	public Date(int ddd, int yyyy)
	{
		setYear(yyyy);
		convertFromDayOfYear(ddd);
	} //end constructor for format DDD YYYY
	
	public void setDay(int dd)
	{
		if(dd >= 1 && dd <= daysInMonth())
			day = dd;
		else
			throw new IllegalArgumentException("Day is wrong!");
		
	} //end method setDay
	
	// Set the month
	public void setMonth(int mm)
	{
		if(mm > 0 && mm <= 12) //validate month
			month = mm;
		else
			throw new IllegalArgumentException("Month is wrong!");
	} //end method setMonth
	
	//Set the year
	public void setYear(int yyyy)
	{
		if(yyyy >= 1900 && yyyy <=2100) //validate year
			year = yyyy;
		else
			throw new IllegalArgumentException("Year is wrong");
	} // end method setYear
	
	public String toString()
	{
		return  String.format("%d/%d/%d", day, month, year);
	} //end method toString
	
	public String toMonthNameDateString()
	{
		return String.format("%s %d, %d", monthNames[month - 1], day, year);
	}//end method toDayDateString
	
	public String toDayDateString()
	{
		return String.format("%d %d", convertToDayOfYear(), year);
	} //end method toDayDateString
	
	private void convertFromMonthName(String monthName)
	{
		for(int subscript = 0; subscript < 12; subscript++)
		{
			if(monthName.equals(monthNames[subscript]))
			{
				setMonth(subscript + 1);
				return; //stop checking for month
			}//end if
		} //end for
		
		setMonth(1); //invalid month; default is january
	}//end convertFromMonthName
	
	private int daysInMonth()
	{
		return leapYear() && month == 2? 29 : monthDays[month - 1];
	}//end method daysofMonth
	
	//test for a leap year
	private boolean leapYear()
	{
		if(year % 400 == 0 ||(year % 4 == 0 && year % 100!= 0))
			return true;
		else
			return false;
	}//end method leapYear
	
	//sets the day and month to the proper values based on ddd
	private void convertFromDayOfYear(int ddd)
	{
		int dayTotal = 0;
		
		if(ddd < 1 || ddd > 366) //check for invalid day
			ddd = 1;
		
		setMonth(1);
		
		for(int m = 1;
				m < 13 && (dayTotal + daysInMonth()) < ddd; ++m)
		{
			dayTotal += daysInMonth();
			setMonth(m + 1);
		} //end for
		
		setDay(ddd - dayTotal);
	}//end convertFromDayOfYear
	
	//convert mm and dd to ddd
	private int convertToDayOfYear()
	{
		int ddd = 0;
		
		for(int m = 1;m < month; ++m)
		{
			if(leapYear() && m == 2)
				ddd += 29;
			else
				ddd += monthDays[m-1];
		} //end for
		
		ddd +=day;
		return ddd;
	} //end method convertToDayOfYear
}
