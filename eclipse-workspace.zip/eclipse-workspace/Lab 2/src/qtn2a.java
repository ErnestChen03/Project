import java.util.Scanner;

public class qtn2a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
