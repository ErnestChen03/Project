import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		int number;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter an integer: ");
		number = input.nextInt();
		
		if (number % 2 == 0) { //whether it can divided by 2
			System.out.println("It's an even number");
			
		}
		else {
			System.out.println("It's an odd number");
		}
	}

}
