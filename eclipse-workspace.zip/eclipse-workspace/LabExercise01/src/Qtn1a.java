import java.util.Scanner;
public class Qtn1a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int num1, num2, num3; //input 3 integers
		int smallest, largest;
		int sum,product;
		float average;
		
		System.out.println("Enter first integer: ");
		num1=input.nextInt();
		System.out.println("Enter second integer: ");
		num2=input.nextInt();
		System.out.println("Enter third integer: ");
		num3=input.nextInt();
		
		sum = num1+num2+num3;
		product = num1*num2*num3;
		average=(float)sum/3;
		
		largest = num1;
		if(num2>largest) {
			largest = num2;
		}
		if (num3>largest) {
			largest = num3;
		}
		
		smallest = num1;
		if(num2<smallest) {
			smallest = num2;
		}
		if (num3<smallest) {
			smallest = num3;
		}
		
		System.out.printf("Sum is %d\n", sum);
		System.out.printf("Product is %d\n", product);
		System.out.printf("Average is %f\n", average);
		System.out.printf("Largest is %d\n", largest);
		System.out.printf("Smallest is %d\n", smallest);
		
		
	
		
	}

}
