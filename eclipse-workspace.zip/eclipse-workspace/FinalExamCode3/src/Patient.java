
public class Patient extends User{
	
	private String nextOfKin;
	private String medHistory;
	
	public Patient()
	{
		
	}

	

	public Patient(String profileIcon, String firstname, String lastname, String username, String birthday, int contactNo,
			String email, String password, String nextOfKin, String medHistory) {
		super(profileIcon, firstname, lastname, username, birthday, contactNo, email, password);
		this.nextOfKin = nextOfKin;
		this.medHistory = medHistory;
	}



	public String getNextOfKin() {
		return nextOfKin;
	}

	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}

	public String getMedHistory() {
		return medHistory;
	}

	public void setMedHistory(String medHistory) {
		this.medHistory = medHistory;
	}

	@Override
	public String toString() {
		return String.format("Patient [nextOfKin=%s, medHistory=%s]", nextOfKin, medHistory);
	}
	
	
	
	

}
