

public class User {
	
	private String profileIcon;
	private String firstname;
	private String lastname;
	private String username;
	private String birthday;
	private int contactNo;
	private String email;
	private String password;
	
	public User()
	{
		
	}

	

	public User(String profileIcon, String firstname, String lastname, String username, String birthday, int contactNo,
			String email, String password) {
		this.profileIcon = profileIcon;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.birthday = birthday;
		this.contactNo = contactNo;
		this.email = email;
		this.password = password;
	}



	public String getProfileIcon() {
		return profileIcon;
	}

	public void setProfileIcon(String profileIcon) {
		this.profileIcon = profileIcon;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return String.format(
				"User [profileIcon=%s, firstname=%s, lastname=%s, username=%s, birthday=%s, contactNo=%s, email=%s, password=%s]",
				profileIcon, firstname, lastname, username, birthday, contactNo, email, password);
	}

		
	
	
}
