import java.util.ArrayList;
import java.util.Date;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Patient p1 = new Patient("[ICON]", "Johnny", "Pierce", "Carrot_142", "12-02-1935", 601234564,
				"Johnny1243@gmail.com", "AHG845343", "Spouse", "Fever");
		Patient p2 = new Patient("[ICON]", "Ben", "Gramp", "apple_542", "16-05-1965", 601235535,
				"Ben5243@gmail.com", "AHG845e3gd", "Children", "Stomach Pain");
		Patient p3 = new Patient("[ICON]", "Kenny", "Darrel", "Banana_172", "19-04-1933", 601253544,
				"Kenny4343@gmail.com", "AHG84fgd3r", "Spouse", "Flu");
		
		Therapist t1 = new Therapist("[ICON]", "Marry", "Taro", "Orange_442", "19-03-1994", 601243425,
				"Johnny1243@gmail.com", "AHG845343", "Addiction", "Vomit");
		Therapist t2 = new Therapist("[ICON]", "Michael", "Davey", "Pizza_132", "11-18-1913", 601435364,
				"Michael343@gmail.com", "A234gdss", "Divorce", "Headache");
		Therapist t3 = new Therapist("[ICON]", "Terry", "Carren", "Fries_142", "12-01-1934", 601233426,
				"Terry0945@gmail.com", "AHG8fs33f", "Children", "Shoulder pain");
		
		Feedback f1 = new Feedback("Very lovely! I loved the service here.", p1, t1);
		Feedback f2 = new Feedback("I like it very much! I wish it offered longer sessions", p2, t2);
		Feedback f3 = new Feedback("This didn't help me as much, but maybe it might for others", p3, t3);
		
		Review r1 = new Review();
		
		r1.addFeedback(f1);		
		r1.addFeedback(f2);		
		r1.addFeedback(f3);		
		
		Appointment a1 = new Appointment(p1, "17/12/2022", "2-4 PM", "Yes", t1, "You have made the appointment sucessfully");
		
		Summary s1 = new Summary(r1, a1);
		
		s1.displayFinalisedSummary();
		

		
		

	}

}
