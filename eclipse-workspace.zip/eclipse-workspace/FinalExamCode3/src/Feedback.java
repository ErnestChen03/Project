
public class Feedback {
	
	private String feedback;
	private Patient patientName;
	private Therapist therapistName;
	
	public Feedback()
	{
		
	}

	public Feedback(String feedback, Patient patientName, Therapist therapistName) {
		this.feedback = feedback;
		this.patientName = patientName;
		this.therapistName = therapistName;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Patient getPatientName() {
		return patientName;
	}

	public void setPatientName(Patient patientName) {
		this.patientName = patientName;
	}

	public Therapist getTherapistName() {
		return therapistName;
	}

	public void setTherapistName(Therapist therapistName) {
		this.therapistName = therapistName;
	}

	@Override
	public String toString() {
		return String.format("Feedback [feedback=%s, patientName=%s, therapistName=%s]", feedback, patientName,
				therapistName);
	}
	
	
}
