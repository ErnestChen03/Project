import java.util.ArrayList;

public class Review {

	private ArrayList<Feedback> feedbacklist = new ArrayList<Feedback>();
	
	public Review()
	{
		
	}

	public Review(ArrayList<Feedback> feedbacklist) {
		this.feedbacklist = feedbacklist;
	}

	public ArrayList<Feedback> getFeedbacklist() {
		return feedbacklist;
	}

	public void setFeedbacklist(ArrayList<Feedback> feedbacklist) {
		this.feedbacklist = feedbacklist;
	}

	@Override
	public String toString() {
		return String.format("Review [feedbacklist=%s]", feedbacklist);
	}
	
	
}
