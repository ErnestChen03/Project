
public class Therapist extends User {

	private String specialities;
	private String service;
	
	public Therapist()
	{
		
	}

	

	public Therapist(String profileIcon, String firstname, String lastname, String username, String birthday, int contactNo,
			String email, String password, String specialities, String service) {
		super(profileIcon, firstname, lastname, username, birthday, contactNo, email, password);
		this.specialities = specialities;
		this.service = service;
	}



	public String getSpecialities() {
		return specialities;
	}

	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	@Override
	public String toString() {
		return String.format("Therapist [specialities=%s, service=%s]", specialities, service);
	}
	
	
}
