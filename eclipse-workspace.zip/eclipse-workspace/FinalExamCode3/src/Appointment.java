
public class Appointment {
	
	private Patient patient;
	private Therapist therapist;
	private String appDate;
	private String appTime;
	private String option;
	private String appMessage;
	
	public Appointment()
	{
		
	}

	public Appointment(Patient patient, Therapist therapist, String appDate, String appTime, String option,
			String appMessage) {
		this.patient = patient;
		this.therapist = therapist;
		this.appDate = appDate;
		this.appTime = appTime;
		this.option = option;
		this.appMessage = appMessage;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Therapist getTherapist() {
		return therapist;
	}

	public void setTherapist(Therapist therapist) {
		this.therapist = therapist;
	}

	public String getAppDate() {
		return appDate;
	}

	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}

	public String getAppTime() {
		return appTime;
	}

	public void setAppTime(String appTime) {
		this.appTime = appTime;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getAppMessage() {
		return appMessage;
	}

	public void setAppMessage(String appMessage) {
		this.appMessage = appMessage;
	}
	
	

	@Override
	public String toString() {
		return String.format("Appointment [patient=%s, therapist=%s, appDate=%s, appTime=%s, option=%s, appMessage=%s]",
				patient, therapist, appDate, appTime, option, appMessage);
	}
	
	
	

}
