import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Customer c1 = new Customer("Bob", "Morgan", "bobmorgs6482@gmail.com", "Ilovehoney3563", "Lawstreet 2454 Park hill", "54");
		Customer c2 = new Customer("Narly", "Chan", "NC7347@gmail.com", "Animelover7402", "Aiobahn 164 Sengoku", "109");
		Customer c3 = new Customer("Napolean", "shun", "Shunknows8436@gmail.com", "Magic435#$", "HevaBills 0238 Darado", "4");
		
		Merchant m1 = new Merchant("Terrance", "Maggie", "Technology9743@gmail.com", "dJetys564", "Bargo Hooter 0385 Creme Bank", "5436653", "2016", "15");
		Merchant m2 = new Merchant("Margo", "Pennie", "Wha2558@gmail.com", "kjjbery675", "Playstreet 6536 Dijarno", "4636573", "2018", "20");
		Merchant m3 = new Merchant("Daiman", "Hans", "HungryBro8302@gmail.com", "crazy3673", "Zephry 9213 Marko Saint", "3903535", "1985", "10");
		
		Product_Info p1 = new Product_Info("Orange", "[ImgOrange]", "Round fresh Orange Fruit", "100", "2.50", "0.2g", m1);
		Product_Info p2 = new Product_Info("Banana", "[ImgBanana]", "Sweet yellow fruit", "75", "3.50", "0.4g", m2);
		Product_Info p3 = new Product_Info("Chocolate", "[ImgChocolate]", "Brown rectangle and sweet", "20", "5.50", "1.75g", m3);
		
		Feedback f1 = new Feedback(5, "I love this online grocery system everything is so convienent!!!");
		Feedback f2 = new Feedback(2, "This grocery system is very buggy hopefully in the future it will be fixed");
		Feedback f3 = new Feedback(4, "For the most part it is really great it is convienent and the food is fresh but I hope more QOL feature will be added to make user experience better");
		
		
		 ArrayList<Product_Info> itemAmt = new ArrayList<Product_Info>();
		    itemAmt.add("Apple");
		    itemAmt.add("Avacado");
		    
		 
		    System.out.println(itemAmt);
		  
		 ArrayList<Product_Info> itemPrice = new ArrayList<Product_Info>();
		 	itemPrice.add("20");
		 	itemPrice.add("10");
		 	
		 ArrayList<Cart> qty = new ArrayList<Cart>();
		 	qty.add("2");
		 	qty.add("1");
		 	
		 ArrayList<Cart> totalPrice = new ArrayList<Cart>();
		 	totalPrice.add(Apple + Avacado);
		 	

	
	
		
		
		System.out.println("----------------------------------");
		System.out.println("e-Groceries shop");
		System.out.println("----------------------------------");
		System.out.println("Name:" firstName + LastName"\t\tTel:" phone "\t\tAddress:" address);
		System.out.println("Order Items");
		System.out.println("-------");
		System.out.println("Name\t\t""Qty""\t\tTotal");
		System.out.println(itemAmt"\t\t"qty"\t\t"itemPrice);
		System.out.println("Total amount paid: RM" totalPrice);
		
	

		
	}
}
