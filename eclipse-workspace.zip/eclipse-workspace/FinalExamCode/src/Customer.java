
public class Customer extends User {
	
	private int ptsEarned;
	
	
	public Customer() {
		
	}


	public Customer(String firstname, String lastname, String email, String password, String address, int phone, int ptsEarned) {
		super(firstname, lastname, email, password, address, phone);
		this.ptsEarned = ptsEarned;
	}


	public int getPtsEarned() {
		return ptsEarned;
	}


	public void setPtsEarned(int ptsEarned) {
		this.ptsEarned = ptsEarned;
	}


	@Override
	public String toString() {
		return String.format("Customer [ptsEarned=%s]", ptsEarned);
	}
	
	


	
	
	
	

}
