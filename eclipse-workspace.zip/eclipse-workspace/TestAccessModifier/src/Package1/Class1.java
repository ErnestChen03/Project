package Package1;

public class Class1 {
	private static int num1;
	public static int num2;
	static int num3; //default -> package access
	protected static int num4; //similar to package access, but allow subclass to access
}
