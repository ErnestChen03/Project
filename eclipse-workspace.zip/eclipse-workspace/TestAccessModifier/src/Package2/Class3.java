package Package2;

import Package1.Class1;

public class Class3 {
	//method
	public void dummy() {
		Class1.num1 = 10;
		Class1.num2 = 10;
		Class1.num3 = 10;
		Class1.num4 = 10;
		
	}
}
