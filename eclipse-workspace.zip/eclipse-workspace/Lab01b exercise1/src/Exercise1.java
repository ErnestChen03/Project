import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double product1 = 0, product2 = 0, product3 = 0;
		Scanner input = new Scanner(System.in);
		int qty, prodnum = -1;
		double total;
		
		while (prodnum !=0) {
			System.out.print("Enter product number (1-3) (0 to stop): ");
			prodnum = input.nextInt();
			if (prodnum !=0) {
				System.out.print("Enter quantity sold: ");
				qty = input.nextInt();
				switch(prodnum) {
					case 1:
						total = qty * 2.98;
						product1 = product1 + total;
						break;
					case 2:
						total = qty * 4.50;
						product2 = product2 + total;
						break;
					case 3:
						total = qty * 9.98;
						product3 = product3 + total;
						break;
					default:
						System.out.println("Wrong product code!");
						break;
						
				}
			}
		}
		System.out.printf("Product 1: $%.2f\n", product1);
		System.out.printf("Product 2: $%.2f\n", product2);
		System.out.printf("Product 3: $%.2f\n", product3);
	}

}
