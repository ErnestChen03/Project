import java.util.Scanner;

public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double num;
		Scanner input = new Scanner(System.in);
		
		//call the constructor
		
		System.out.print("Account1 balance: $");
		num = input.nextDouble();
		Account account1 = new Account(num); //create account 1
		
		System.out.print("Account2 balance: $");
		num = input.nextDouble();
		Account account2 = new Account(num); //create account 2
		
		//prompt for deposit
		
		System.out.printf("Enter amount to be deposited account 1 $:");
		num = input.nextDouble();
		account1.credit(num);
		
		System.out.printf("Enter amount to be deposited account 2 $:");
		num = input.nextDouble();
		account2.credit(num);
		
		System.out.printf("Balance in account 1 $ %.2f\n", account1.getBalance());
		System.out.printf("Balance in account 2 $ %.2f\n", account2.getBalance());
		
		System.out.printf("Enter amount to be withdrawn account 1 $:");
		num = input.nextDouble();
		account1.debit(num);
		
		System.out.printf("Enter amount to be withdrawn account 2 $:");
		num = input.nextDouble();
		account2.debit(num);
		
		//display the balance
		System.out.printf("Balance in account 1 $ %.2f\n", account1.getBalance());
		System.out.printf("Balance in account 2 $ %.2f\n", account2.getBalance());
		
		System.out.println("Total balance of all account us $: " +Account.getTotal());
		
		

	}

}
