
public class Account {
	private double balance; //initial balance
	//introduce a new class variable
	private static double total=0;
	
	//constructor 
	public Account(double InitialBalance) {
		//if if (InitialBalance >0) {//to protect from user giving negative values
			setBalance(InitialBalance);
		}
	
	
	//setter - to check for negative input
	public void setBalance(double b) {	
		if (b>0) {
			balance = b;
		}
	}
	
	public double getBalance() {
		return balance;
	}
	public void credit(double amount) {//when ppl deposit money
		//if(amount >0) {
		setBalance(balance +amount);
		
	}
	
	public void debit(double amount) {//when ppl withdraw money
		if(amount>balance) {
			System.out.println("Debit amount exceed the balance");
		}
		else {
			
			setBalance(balance -amount);
			decreaseTotal(amount);
	}
	}
	
	//introduce the 3 new methods
	public static void increaseTotal(double amount) {
		total = total + amount;
	}
	public static void decreaseTotal(double amount) {
		total = total - amount;
	}
	public static double getTotal() {
		return total;
	}
	
}