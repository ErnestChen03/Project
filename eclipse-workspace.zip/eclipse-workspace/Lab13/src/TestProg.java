import java.util.*;

public class TestProg {
	
	public static void main(String[] args) {
		Staff s = new Staff("Mindy", "Bandar Sunway", "Sunway University", 3000);
		s.setSchool("Sunway College");
		System.out.println(s);
		System.out.println();
		
		Student[] students = new Student[3];
		students[0] = new Student("Ahmad", "Johor", "BIT", 2017, 1580);
		students[1] = new Student("John", "Pahang", "BCS", 2016, 1400);
		students[2] = new Student("Sally", "Selangor", "BSE", 2015, 1350);
		Staff lecturer = new Staff("Mindy", "Bandar Sunway", "Sunway University", 3000);
		Subject sub = new Subject("PRG1203", students, lecturer);
		System.out.println(sub);
		System.out.println();
		
		//Then create an ArrayList to hold all the students and lecturer, print out all the objects by looping through
		ArrayList<Person> plist = new ArrayList<Person>();
		plist.add(students[0]);
		plist.add(students[1]);
		plist.add(students[2]);
		plist.add(lecturer);
		System.out.println("The list of persons are:");
		for (Person p: plist) {
			System.out.println(p);
		}
		
	}

}
