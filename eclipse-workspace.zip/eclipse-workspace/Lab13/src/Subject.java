import java.util.*;

public class Subject {
	private String code;
	private Student[] slist;
	private Staff lecturer;
	
	public Subject() {
		
	}
	
	public Subject(String code, Student[] slist, Staff lecturer) {
		setSubjectCode(code);
		setStudents(slist);
		setLecturer(lecturer);
	}
	
	public void setSubjectCode(String code) {
		this.code = code;
	}
	public void setStudents(Student[] slist) {
		this.slist = slist;
	}
	public void setLecturer(Staff lecturer) {
		this.lecturer = lecturer;
	}
	public String getSubjectCode() {
		return code;
	}
	public Student[] getStudents() {
		return slist;
	}
	public Staff getLecturer() {
		return lecturer;
	}
	@Override
	public String toString() {
		return String.format("Subject[code=%s, students={%s}, lecturer=%s]", getSubjectCode(), Arrays.toString(getStudents()), getLecturer());
	}
}
