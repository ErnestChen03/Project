import java.util.Scanner;
public class qtn1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1.define original array with 5 elements
		int[]numbers;
		//prompt the user to enter the size of the array
		numbers = new int[5];
		int count = 0;
		int number;
		
		Scanner input = new Scanner(System.in);
		//2.write a while loop to key in 5 no
		while(count<numbers.length) {
			System.out.print("\nEnter a number: ");
			number = input.nextInt(); // enter into a variable
			
			if((number>=10)&&(number<=100))
			{
				//check if it's duplicate
				boolean containNumbers=false;
				for(int index=0; index<numbers.length; index++) {
					if (number==numbers[index]) {
						containNumbers=true;
						break;
					}
				}
				if(!containNumbers) {
					numbers[count]=number;//store in array
					count++;
				}
				else {
					System.out.printf("%d Already entered\n", number);
					 }
			}
			else
			   {
				System.out.println("Number must be betweem 10 and 100");
			   }
			for(int index=0; index<count;index++) {
				System.out.printf(numbers[index] + " ");
				
			}
		}
	}
	
}
