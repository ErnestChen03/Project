
public class Merchant extends User {
	
	private int regNumber;
	private int	yearEst;
	private int employeeNum;
	
	public Merchant() {
		
	}

	public Merchant(String firstname, String lastname, String email, String password, String address, int phone, int regNumber, int yearEst, int employeeNum) {
		super(firstname, lastname, email, password, address, phone);
		this.regNumber = regNumber;
		this.yearEst = yearEst;
		this.employeeNum = employeeNum;
	}

	public int getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(int regNumber) {
		this.regNumber = regNumber;
	}

	public int getYearEst() {
		return yearEst;
	}

	public void setYearEst(int yearEst) {
		this.yearEst = yearEst;
	}

	public int getEmployeeNum() {
		return employeeNum;
	}

	public void setEmployeeNum(int employeeNum) {
		this.employeeNum = employeeNum;
	}

	@Override
	public String toString() {
		return String.format("Merchant [regNumber=%s, yearEst=%s, employeeNum=%s]", regNumber, yearEst, employeeNum);
	}

	
	
	
	
	

}
