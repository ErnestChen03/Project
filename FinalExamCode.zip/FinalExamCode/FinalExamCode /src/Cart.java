import java.util.ArrayList;

public class Cart {
	private Product_Info itemName;
	private Product_Info itemImg;
	private ArrayList<Product_Info> itemAmt = new ArrayList<Product_Info>();
	private ArrayList<Product_Info> itemPrice = new ArrayList<Product_Info>();
	private ArrayList<Cart> totalPrice = new ArrayList<Cart>();
	private ArrayList<Cart> qty = new ArrayList<Cart>();
	
	public Cart() {
		
	}

	public Cart(Product_Info itemName, Product_Info itemImg, ArrayList<Product_Info> itemAmt,
			ArrayList<Product_Info> itemPrice, ArrayList<Cart> totalPrice, ArrayList<Cart> qty) {
		super();
		this.itemName = itemName;
		this.itemImg = itemImg;
		this.itemAmt = itemAmt;
		this.itemPrice = itemPrice;
		this.totalPrice = totalPrice;
		this.qty = qty;
	}

	public Product_Info getItemName() {
		return itemName;
	}

	public void setItemName(Product_Info itemName) {
		this.itemName = itemName;
	}

	public Product_Info getItemImg() {
		return itemImg;
	}

	public void setItemImg(Product_Info itemImg) {
		this.itemImg = itemImg;
	}

	public ArrayList<Product_Info> getItemAmt() {
		return itemAmt;
	}

	public void setItemAmt(ArrayList<Product_Info> itemAmt) {
		this.itemAmt = itemAmt;
	}

	public ArrayList<Product_Info> getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(ArrayList<Product_Info> itemPrice) {
		this.itemPrice = itemPrice;
	}

	public ArrayList<Cart> getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(ArrayList<Cart> totalPrice) {
		this.totalPrice = totalPrice;
	}

	public ArrayList<Cart> getQty() {
		return qty;
	}

	public void setQty(ArrayList<Cart> qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return String.format("Cart [itemName=%s, itemImg=%s, itemAmt=%s, itemPrice=%s, totalPrice=%s, qty=%s]",
				itemName, itemImg, itemAmt, itemPrice, totalPrice, qty);
	}

		
}
