
public class Feedback {
	
	private int Rate;
	private String entFeedback;
	
	public Feedback() {
		
	}

	public Feedback(int rate, String entFeedback) {
		Rate = rate;
		this.entFeedback = entFeedback;
	}

	public int getRate() {
		return Rate;
	}

	public void setRate(int rate) {
		Rate = rate;
	}

	public String getEntFeedback() {
		return entFeedback;
	}

	public void setEntFeedback(String entFeedback) {
		this.entFeedback = entFeedback;
	}

	@Override
	public String toString() {
		return String.format("Feedback [Rate=%s, entFeedback=%s]", Rate, entFeedback);
	}
	
	
	
	
	
	

}
