
public class Product_Info {
	
	private String itemName;
	private String itemImg;
	private String itemDesc;
	private int stockAmt;
	private Double itemPrice;
	private String measureMx;
	private Merchant merchant;
	
	public Product_Info() {
		
	}
	
	
	public Product_Info(String itemName, String itemImg, String itemDesc, int stockAmt, Double itemPrice,
			String measureMx, Merchant merchant) {
		this.itemName = itemName;
		this.itemImg = itemImg;
		this.itemDesc = itemDesc;
		this.stockAmt = stockAmt;
		this.itemPrice = itemPrice;
		this.measureMx = measureMx;
		this.merchant = merchant;
	}
	
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemImg() {
		return itemImg;
	}
	public void setItemImg(String itemImg) {
		this.itemImg = itemImg;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public int getStockAmt() {
		return stockAmt;
	}
	public void setStockAmt(int stockAmt) {
		this.stockAmt = stockAmt;
	}
	public Double getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getMeasureMx() {
		return measureMx;
	}
	public void setMeasureMx(String measureMx) {
		this.measureMx = measureMx;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	@Override
	public String toString() {
		return String.format(
				"Product_Info [itemName=%s, itemImg=%s, itemDesc=%s, stockAmt=%s, itemPrice=%s, measureMx=%s, merchant=%s]",
				itemName, itemImg, itemDesc, stockAmt, itemPrice, measureMx, merchant);
	}
	
	
	
	

}
