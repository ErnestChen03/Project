
public class Product_List {
	private String nuts;
	private String fruits;
	private String vegetables;
	private String sodas;
	private User address;
	private Customer customer;
	private Merchant merchant;
	
	public Product_List() {
		
	}

	public Product_List(String nuts, String fruits, String vegetables, String sodas, User address, Customer customer,
			Merchant merchant) {
		this.nuts = nuts;
		this.fruits = fruits;
		this.vegetables = vegetables;
		this.sodas = sodas;
		this.address = address;
		this.customer = customer;
		this.merchant = merchant;
	}

	public String getNuts() {
		return nuts;
	}

	public void setNuts(String nuts) {
		this.nuts = nuts;
	}

	public String getFruits() {
		return fruits;
	}

	public void setFruits(String fruits) {
		this.fruits = fruits;
	}

	public String getVegetables() {
		return vegetables;
	}

	public void setVegetables(String vegetables) {
		this.vegetables = vegetables;
	}

	public String getSodas() {
		return sodas;
	}

	public void setSodas(String sodas) {
		this.sodas = sodas;
	}

	public User getAddress() {
		return address;
	}

	public void setAddress(User address) {
		this.address = address;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	@Override
	public String toString() {
		return String.format(
				"Product_List [nuts=%s, fruits=%s, vegetables=%s, sodas=%s, address=%s, customer=%s, merchant=%s]",
				nuts, fruits, vegetables, sodas, address, customer, merchant);
	}
	
	
	
	
}
