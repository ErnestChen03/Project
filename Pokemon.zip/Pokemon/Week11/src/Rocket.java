import java.util.Random;

public class Rocket extends SpaceObject{
	
	public Rocket() {
		super(5);
		//randomize the power value
		Random r = new Random();		
		setPower(r.nextInt(10));
	}
	
	@Override
	public void draw() {
		//rocket
		System.out.println("           ___");
		System.out.println("     |     | |");
		System.out.println("    / \\    | |");
		System.out.println("   |--o|===|-|");
		System.out.println("   |---|   |d|");
		System.out.println("  /     \\  |w|");
		System.out.println(" | U     | |b|");
		System.out.println(" | S     |=| |");
		System.out.println(" | A     | | |");
		System.out.println(" |_______| |_|");
		System.out.println("  |@| |@|  | |");
		System.out.println("___________|_|_");	
		
	}
	
}
