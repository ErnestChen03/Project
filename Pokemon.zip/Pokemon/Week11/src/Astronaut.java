
public class Astronaut extends SpaceObject{

	@Override
	public void draw() {
		//astronaut
		System.out.println("       _..._");
		System.out.println("      .'     '.      _");
		System.out.println("     /    .-\"\"-\\   _/ \\");
		System.out.println("   .-|   /:.   |  |   |");
		System.out.println("   |  \\  |:.   /.-'-./");
		System.out.println("   | .-'-;:__.'    =/");
		System.out.println("   .'=  *=|NASA _.='");
		System.out.println("  /   _.  |    ;");
		System.out.println(" ;-.-'|    \\   |");
		System.out.println("/   | \\    _\\  _\\");
		System.out.println("\\__/'._;.  ==' ==\\");
		System.out.println("         \\    \\   |");
		System.out.println("         /    /   /");
		System.out.println("         /-._/-._/");
		System.out.println("         \\   `\\  \\");
		System.out.println("          `-._/._/");				
	}
	
	public void wave() {
		System.out.println("Hello World!");
	}
}
