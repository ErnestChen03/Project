public class PokeBall {
    private String type;
    private double successRate;

    public PokeBall(String type, double successRate) {
        this.type = type;
        this.successRate = successRate;
    }

    public boolean attemptCatch(Pokemon pokemon) {
        // Logic to attempt catching a Pokémon
        return Math.random() < successRate;
    }
}
